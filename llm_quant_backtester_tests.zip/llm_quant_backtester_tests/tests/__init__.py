# Init for LLM Quant Backtester tests
