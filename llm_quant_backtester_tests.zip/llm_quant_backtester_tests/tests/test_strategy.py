import pytest
import pandas as pd
from strategy import generate_signals

def test_generate_signals_empty():
    df = pd.DataFrame(columns=['price'])
    signals = generate_signals(df)
    assert isinstance(signals, pd.Series)
    assert signals.empty

def test_generate_signals_simple():
    df = pd.DataFrame({'price': [100, 102, 101, 105]})
    signals = generate_signals(df)
    assert len(signals) == len(df)
    assert set(signals.unique()).issubset({-1, 0, 1})
