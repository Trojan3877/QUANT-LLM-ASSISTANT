import pytest
import pandas as pd
from backtester import run_backtest

def test_run_backtest_basic():
    df = pd.DataFrame({
        'date': pd.to_datetime(['2020-01-01','2020-01-02']),
        'price': [100, 110]
    })
    def mock_strategy(data):
        return pd.Series([1, -1], index=data.index)
    results = run_backtest(df, mock_strategy)
    assert 'returns' in results
    assert pytest.approx(0.1, rel=1e-3) == results['returns'].iloc[-1]

def test_run_backtest_no_trades():
    df = pd.DataFrame({
        'date': pd.to_datetime(['2020-01-01']),
        'price': [100]
    })
    def empty_strategy(data):
        return pd.Series([0], index=data.index)
    results = run_backtest(df, empty_strategy)
    assert results['returns'].iloc[0] == 0
