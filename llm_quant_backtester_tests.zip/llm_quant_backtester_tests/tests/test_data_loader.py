import pytest
import pandas as pd
from data_loader import load_data

def test_load_data_valid(tmp_path):
    # Create a sample CSV file with date and price
    csv_file = tmp_path / 'sample.csv'
    csv_file.write_text('date,price\n2020-01-01,100\n2020-01-02,101\n')
    df = load_data(str(csv_file))
    assert not df.empty
    assert list(df.columns) == ['date', 'price']
    assert df.iloc[0]['price'] == 100

def test_load_data_missing_file():
    with pytest.raises(FileNotFoundError):
        load_data('non_existent.csv')
